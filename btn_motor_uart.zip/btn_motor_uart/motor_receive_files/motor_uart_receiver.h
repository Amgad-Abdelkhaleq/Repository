#ifndef __motor_uart_receive_h__
#define	__motor_uart_receive_h__

#include "stdint.h"
void UART5_init(void);
uint8_t UART5_Rx(void);

#endif 