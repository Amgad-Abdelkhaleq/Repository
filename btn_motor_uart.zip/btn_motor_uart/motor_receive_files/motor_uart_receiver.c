#include "tm4c123gh6pm.h"
#include "stdint.h"

void UART5_init (void){
SYSCTL_RCGCUART_R |=0x20; //provide clock to UART5
SYSCTL_RCGCGPIO_R |=0x10; //enable clock to PORTE
	//UART5 initialaization 
UART5_CTL_R=0; //disable uart5
UART5_IBRD_R=520; // 80MHZ/16*9600     (	NOT SURE IF 80MHZ OR 16MHZ )
UART5_FBRD_R=53;
UART5_LCRH_R=	0x70; //no parity,enable FIFO,width=8bit,1-stop bit
UART5_CTL_R=0x301; //enable UART5,TXE and RXE
  //GPIO config
GPIO_PORTE_DEN_R=0x30;    // make PE5,PE4 as digital
GPIO_PORTE_AMSEL_R=0;    //disable analog function 
GPIO_PORTE_AFSEL_R=0x30; //use PE5 and PE4 alternate function 
GPIO_PORTE_PCTL_R=0x00110000; //configure PE%,PE4 fot UART5
}


uint8_t UART5_Rx(void){
while((UART5_FR_R & 0x0010)!=0); //wait untill RXFE=0 (FIFO full)
return (UART5_DR_R & 0xff);  //retrun data (first 8-bit)
}