#include "tm4c123gh6pm.h"
#include "PLL.h"
#include "motor_uart_receiver.c"
#include "stdint.h"

void SystemInit(void){
	PLL_Init();
	UART5_init ();
}

int main(void){
 uint8_t received_char;   
while(1){
received_char= UART5_Rx(void);
switch (received_char)
{
case 'A':
		/* turn motor 30 degree clockwise */
		break;

case 'B':
		/* trun motor 30 degree anti-clockwise */
		break;

case 'C':
		/* do nothing */
		break;

default:
       /*error flag*/
		break;
}


    }
}